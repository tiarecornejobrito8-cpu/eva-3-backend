# IMPORTACIONES


from django.contrib import admin
from django.urls import path
from django.contrib.auth.views import LogoutView

# Vistas de nuestras aplicaciones
from core import views as CoreViews
from cuentas import views as CuentasViews
from experiencias import views as ExperienciasViews


# ==========================================
# RUTAS PRINCIPALES
# ==========================================

urlpatterns = [

    # ======================================
    # DJANGO ADMIN INDEPENDIENTE
    # ======================================

    path(
        'admin/',
        admin.site.urls
    ),

    # ======================================
    # PÁGINA PRINCIPAL
    # ======================================

    path(
        '',
        CoreViews.landingPage,
        name='landingPage'
    ),

    # ======================================
    # REGISTRO Y AUTENTICACIÓN
    # ======================================

    path(
        'usuarios/registrar-turista/',
        CuentasViews.CrearCuentaViewTurista.as_view(),
        name='registrar_turista'
    ),

    path(
        'usuarios/registrar-guia/',
        CuentasViews.CrearCuentaViewGuia.as_view(),
        name='registrar_guia'
    ),

    path(
        'usuarios/iniciar-sesion/',
        CuentasViews.IniciarSesionView.as_view(),
        name='iniciar_sesion'
    ),

    path(
        'usuarios/cerrar-sesion/',
        LogoutView.as_view(
            next_page='landingPage'
        ),
        name='cerrar_sesion'
    ),

    # ======================================
    # CRUD DE USUARIOS - SB ADMIN 2
    # ======================================

    path(
        'usuarios/',
        CuentasViews.listarUsuarios,
        name='listar_usuarios'
    ),

    path(
        'usuarios/registrar/',
        CuentasViews.registrarUsuario,
        name='registrar_usuario'
    ),

    path(
        'usuarios/editar/<int:id_usuario>/',
        CuentasViews.editarUsuario,
        name='editar_usuario'
    ),

    path(
        'usuarios/eliminar/<int:id_usuario>/',
        CuentasViews.eliminarUsuario,
        name='eliminar_usuario'
    ),

    # ======================================
    # CATEGORÍAS
    # ======================================

    path(
        'categorias/',
        ExperienciasViews.listarCategorias,
        name='listar_categorias'
    ),

    path(
        'categorias/registrar/',
        ExperienciasViews.registrarCategoria,
        name='registrar_categoria'
    ),

    path(
        'categorias/editar/<int:id_categoria>/',
        ExperienciasViews.editarCategoria,
        name='editar_categoria'
    ),

    path(
        'categorias/eliminar/<int:id_categoria>/',
        ExperienciasViews.eliminarCategoria,
        name='eliminar_categoria'
    ),

    # ======================================
    # EXPERIENCIAS
    # ======================================

    path(
        'experiencias/catalogo/',
        ExperienciasViews.catalogoExperiencias,
        name='catalogo_experiencias'
    ),

    path(
        'experiencias/',
        ExperienciasViews.listarExperiencias,
        name='listar_experiencias'
    ),

    path(
        'experiencias/registrar/',
        ExperienciasViews.registrarExperiencia,
        name='registrar_experiencia'
    ),

    path(
        'experiencias/editar/<int:id_experiencia>/',
        ExperienciasViews.editarExperiencia,
        name='editar_experiencia'
    ),

    path(
        'experiencias/eliminar/<int:id_experiencia>/',
        ExperienciasViews.eliminarExperiencia,
        name='eliminar_experiencia'
    ),

    # ======================================
    # RESERVAS Y PAGOS
    # ======================================

    path(
        'reservas/registrar/',
        ExperienciasViews.registrarReserva,
        name='registrar_reserva'
    ),

    path(
        'reservas/',
        ExperienciasViews.listarReservas,
        name='listar_reservas'
    ),

    path(
        'reservas/pago/<int:id_reserva>/',
        ExperienciasViews.actualizarEstadoReserva,
        name='actualizar_estado_reserva'
    ),
]
