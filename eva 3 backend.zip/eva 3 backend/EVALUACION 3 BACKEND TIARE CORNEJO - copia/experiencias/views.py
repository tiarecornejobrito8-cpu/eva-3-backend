# IMPORTACIONES

# Mostrar páginas, redireccionar y buscar registros
from django.shortcuts import render, redirect, get_object_or_404

# Comprobar que el usuario inició sesión
from django.contrib.auth.decorators import login_required

# Control de permisos
from django.core.exceptions import PermissionDenied

# Limitar las eliminaciones al método POST
from django.views.decorators.http import require_POST

# Mensajes para el usuario
from django.contrib import messages

# Manejo de fechas y transacciones
from django.utils import timezone
from django.db import transaction

# Control de categorías relacionadas
from django.db.models.deletion import ProtectedError

# Modelos y formularios de nuestra aplicación
from experiencias import models as ModelsExperiencias
from experiencias import forms as FormsExperiencias

# VALIDACIÓN DE ROLES

# Comprueba si el usuario tiene permisos administrativos
def es_administrador(usuario):

    return (
        usuario.is_authenticated
        and usuario.is_active
        and (
            usuario.is_superuser
            or (
                usuario.is_staff
                and usuario.is_custom_admin
            )
        )
    )


# Comprueba si el usuario es guía
def es_guia(usuario):

    return (
        usuario.is_authenticated
        and usuario.is_active
        and usuario.is_guia
        and not usuario.is_superuser
    )


# Comprueba si el usuario es turista
def es_turista(usuario):

    return (
        usuario.is_authenticated
        and usuario.is_active
        and usuario.is_turista
    )

# GESTIÓN DE CATEGORÍAS
# SOLO ADMINISTRADOR

@login_required(login_url='iniciar_sesion')
def listarCategorias(request):

    # Solo el administrador puede acceder
    if not es_administrador(request.user):
        raise PermissionDenied

    # Se obtienen las categorías guardadas en MySQL
    categorias = ModelsExperiencias.Categoria.objects.all()

    data = {
        'categorias': categorias
    }

    return render(
        request,
        'experiencias/lista_categorias.html',
        data
    )


# Registrar una categoría
@login_required(login_url='iniciar_sesion')
def registrarCategoria(request):

    if not es_administrador(request.user):
        raise PermissionDenied

    # Se crea el formulario CATEGORÍA
    formCategoria = FormsExperiencias.CategoriaForm()

    if request.method == 'POST':

        formCategoria = FormsExperiencias.CategoriaForm(
            request.POST
        )

        if formCategoria.is_valid():

            # Se guarda la categoría en MySQL
            formCategoria.save()

            messages.success(
                request,
                'Categoría registrada correctamente.'
            )

            return redirect('listar_categorias')

    data = {
        'formKey': formCategoria,
        'titulo_pagina': 'Registrar categoría'
    }

    return render(
        request,
        'experiencias/formulario_categoria.html',
        data
    )


# Editar una categoría
@login_required(login_url='iniciar_sesion')
def editarCategoria(request, id_categoria):

    if not es_administrador(request.user):
        raise PermissionDenied

    # Se busca el registro
    categoria = get_object_or_404(
        ModelsExperiencias.Categoria,
        pk=id_categoria
    )

    # Se cargan sus datos actuales
    formCategoria = FormsExperiencias.CategoriaForm(
        instance=categoria
    )

    if request.method == 'POST':

        formCategoria = FormsExperiencias.CategoriaForm(
            request.POST,
            instance=categoria
        )

        if formCategoria.is_valid():

            formCategoria.save()

            messages.success(
                request,
                'Categoría actualizada correctamente.'
            )

            return redirect('listar_categorias')

    data = {
        'formKey': formCategoria,
        'titulo_pagina': 'Editar categoría'
    }

    return render(
        request,
        'experiencias/formulario_categoria.html',
        data
    )


# Eliminar una categoría
@login_required(login_url='iniciar_sesion')
@require_POST
def eliminarCategoria(request, id_categoria):

    if not es_administrador(request.user):
        raise PermissionDenied

    categoria = get_object_or_404(
        ModelsExperiencias.Categoria,
        pk=id_categoria
    )

    try:
        # Se elimina si no tiene experiencias relacionadas
        categoria.delete()

        messages.success(
            request,
            'Categoría eliminada correctamente.'
        )

    except ProtectedError:

        # Se protege la información relacionada
        messages.error(
            request,
            'No se puede eliminar una categoría que tiene experiencias.'
        )

    return redirect('listar_categorias')

# GESTIÓN DE EXPERIENCIAS
# ADMINISTRADOR Y GUÍA

@login_required(login_url='iniciar_sesion')
def listarExperiencias(request):

    if es_administrador(request.user):

        # El administrador puede ver todas las experiencias
        experiencias = ModelsExperiencias.Experiencia.objects.all()

    elif es_guia(request.user):

        # El guía solo puede ver experiencias de su autoría
        experiencias = ModelsExperiencias.Experiencia.objects.filter(
            creador=request.user
        )

    else:
        raise PermissionDenied

    experiencias = experiencias.select_related(
        'categoria',
        'creador'
    )

    data = {
        'experiencias': experiencias
    }

    return render(
        request,
        'experiencias/lista_experiencias.html',
        data
    )


# Registrar una experiencia
@login_required(login_url='iniciar_sesion')
def registrarExperiencia(request):

    # Solo Administrador y Guía pueden registrar
    if not (
        es_administrador(request.user)
        or es_guia(request.user)
    ):
        raise PermissionDenied

    formExperiencia = FormsExperiencias.ExperienciaForm()

    if request.method == 'POST':

        formExperiencia = FormsExperiencias.ExperienciaForm(
            request.POST
        )

        if formExperiencia.is_valid():

            # Se prepara la experiencia
            experiencia = formExperiencia.save(commit=False)

            # El creador es quien inició sesión
            experiencia.creador = request.user

            # Se guarda la experiencia
            experiencia.save()

            messages.success(
                request,
                'Experiencia registrada correctamente.'
            )

            return redirect('listar_experiencias')

    data = {
        'formKey': formExperiencia,
        'titulo_pagina': 'Registrar experiencia'
    }

    return render(
        request,
        'experiencias/formulario_experiencia.html',
        data
    )


# Adaptación de editarEXPERIENCIA 
@login_required(login_url='iniciar_sesion')
def editarExperiencia(request, id_experiencia):

    if es_administrador(request.user):

        # El administrador puede editar cualquier experiencia
        experiencia = get_object_or_404(
            ModelsExperiencias.Experiencia,
            pk=id_experiencia
        )

    elif es_guia(request.user):

        # El guía solo puede editar experiencias propias
        experiencia = get_object_or_404(
            ModelsExperiencias.Experiencia,
            pk=id_experiencia,
            creador=request.user
        )

    else:
        raise PermissionDenied

    formExperiencia = FormsExperiencias.ExperienciaForm(
        instance=experiencia
    )

    if request.method == 'POST':

        formExperiencia = FormsExperiencias.ExperienciaForm(
            request.POST,
            instance=experiencia
        )

        if formExperiencia.is_valid():

            # Se comprueba que los cupos no sean inferiores
            # a las reservas que ya existen
            reservas_actuales = experiencia.reservas.count()

            cupos_nuevos = formExperiencia.cleaned_data[
                'cupo_maximo'
            ]

            if cupos_nuevos < reservas_actuales:

                formExperiencia.add_error(
                    'cupo_maximo',
                    'No puede ser menor que las reservas existentes.'
                )

            else:

                # Se guardan los cambios
                # sin modificar al usuario creador
                formExperiencia.save()

                messages.success(
                    request,
                    'Experiencia actualizada correctamente.'
                )

                return redirect('listar_experiencias')

    data = {
        'formKey': formExperiencia,
        'titulo_pagina': 'Editar experiencia'
    }

    return render(
        request,
        'experiencias/formulario_experiencia.html',
        data
    )


# Adaptación de eliminarEXPERIENCIA
@login_required(login_url='iniciar_sesion')
@require_POST
def eliminarExperiencia(request, id_experiencia):

    # Los guías NO pueden eliminar experiencias
    if not es_administrador(request.user):
        raise PermissionDenied

    experiencia = get_object_or_404(
        ModelsExperiencias.Experiencia,
        pk=id_experiencia
    )

    # No se elimina si existen reservas
    if experiencia.reservas.exists():

        messages.error(
            request,
            'No se puede eliminar una experiencia con reservas.'
        )

    else:

        experiencia.delete()

        messages.success(
            request,
            'Experiencia eliminada correctamente.'
        )

    return redirect('listar_experiencias')

# CATÁLOGO PÚBLICO

# Mostrar experiencias activas y futuras
def catalogoExperiencias(request):

    experiencias = (
        ModelsExperiencias.Experiencia.objects
        .select_related('categoria')
        .filter(
            activo=True,
            categoria__estado=True,
            fecha_hora__gt=timezone.now()
        )
    )

    data = {
        'experiencias': experiencias
    }

    return render(
        request,
        'experiencias/catalogo.html',
        data
    )

# RESERVAS DEL TURISTA

# Adaptación del registro RESERVAS
@login_required(login_url='iniciar_sesion')
def registrarReserva(request):

    # Solamente los turistas pueden reservar
    if not es_turista(request.user):
        raise PermissionDenied

    formReserva = FormsExperiencias.ReservaForm()

    # Se permite preseleccionar una experiencia
    if request.method == 'GET':

        experiencia_id = request.GET.get('experiencia')

        if experiencia_id:
            formReserva.initial['experiencia'] = experiencia_id

    if request.method == 'POST':

        formReserva = FormsExperiencias.ReservaForm(
            request.POST
        )

        if formReserva.is_valid():

            # Se obtiene la experiencia seleccionada
            experiencia_elegida = formReserva.cleaned_data[
                'experiencia'
            ]

            # Transacción para controlar los cupos
            with transaction.atomic():

                # Se bloquea el registro mientras se reserva
                experiencia = get_object_or_404(
                    ModelsExperiencias.Experiencia.objects
                    .select_for_update()
                    .select_related('categoria'),
                    pk=experiencia_elegida.pk
                )

                # Se comprueba que siga disponible
                disponible = (
                    experiencia.activo
                    and experiencia.categoria.estado
                    and experiencia.fecha_hora > timezone.now()
                )

                # Se comprueba si ya reservó esta actividad
                reserva_existente = experiencia.reservas.filter(
                    usuario=request.user
                ).exists()

                # Se cuentan todas las reservas de la experiencia
                cupos_ocupados = experiencia.reservas.count()

                if not disponible:

                    formReserva.add_error(
                        'experiencia',
                        'Esta experiencia ya no está disponible.'
                    )

                elif reserva_existente:

                    formReserva.add_error(
                        'experiencia',
                        'Ya tienes una reserva para esta experiencia.'
                    )

                elif cupos_ocupados >= experiencia.cupo_maximo:

                    formReserva.add_error(
                        'experiencia',
                        'No quedan cupos disponibles.'
                    )

                else:

                    # Se prepara la reserva
                    reserva = formReserva.save(commit=False)

                    # Se asigna automáticamente el turista
                    reserva.usuario = request.user

                    # Se asigna la experiencia elegida
                    reserva.experiencia = experiencia

                    # El pago comienza en estado Pendiente
                    reserva.estado_pago = (
                        ModelsExperiencias.Reserva.ESTADO_PENDIENTE
                    )

                    # Se guarda en MySQL
                    reserva.save()

                    messages.success(
                        request,
                        'Reserva registrada correctamente.'
                    )

                    return redirect('listar_reservas')

    data = {
        'formKey': formReserva,
        'titulo_pagina': 'Reservar experiencia'
    }

    return render(
        request,
        'experiencias/formulario_reserva.html',
        data
    )

# LISTADO E HISTORIAL DE RESERVAS

@login_required(login_url='iniciar_sesion')
def listarReservas(request):

    if es_administrador(request.user):

        # El administrador ve todas las reservas
        reservas = ModelsExperiencias.Reserva.objects.all()

    elif es_turista(request.user):

        # El turista ve solamente sus reservas
        reservas = ModelsExperiencias.Reserva.objects.filter(
            usuario=request.user
        )

    else:
        raise PermissionDenied

    reservas = reservas.select_related(
        'usuario',
        'experiencia'
    )

    data = {
        'reservas': reservas
    }

    return render(
        request,
        'experiencias/lista_reservas.html',
        data
    )

# ACTUALIZAR ESTADO DE PAGO

# Solo el administrador puede actualizar pagos
@login_required(login_url='iniciar_sesion')
def actualizarEstadoReserva(request, id_reserva):

    if not es_administrador(request.user):
        raise PermissionDenied

    reserva = get_object_or_404(
        ModelsExperiencias.Reserva,
        pk=id_reserva
    )

    formPago = FormsExperiencias.ReservaEstadoForm(
        instance=reserva
    )

    if request.method == 'POST':

        formPago = FormsExperiencias.ReservaEstadoForm(
            request.POST,
            instance=reserva
        )

        if formPago.is_valid():

            formPago.save()

            messages.success(
                request,
                'Estado de pago actualizado correctamente.'
            )

            return redirect('listar_reservas')

    data = {
        'formKey': formPago,
        'titulo_pagina': 'Actualizar estado de pago'
    }

    return render(
        request,
        'experiencias/formulario_pago.html',
        data
    )
