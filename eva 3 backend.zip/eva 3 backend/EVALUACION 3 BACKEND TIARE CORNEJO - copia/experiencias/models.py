
# IMPORTACIONES

from django.db import models
from django.conf import settings
from django.core.validators import MinValueValidator


# MODELO DE CATEGORÍAS

# Permite registrar las categorías de las actividades
class Categoria(models.Model):

    # Nombre de la categoría
    nombre = models.CharField(max_length=100)

    # Descripción de la categoría
    descripcion = models.TextField()

    # Estado activo o inactivo
    estado = models.BooleanField(default=True)

    # Ordena las categorías por nombre
    class Meta:
        ordering = ['nombre']

    # Muestra el nombre de la categoría
    def __str__(self):
        return self.nombre


# MODELO DE EXPERIENCIAS

# Adaptación del modelo Curso de nuestro compañero
class Experiencia(models.Model):

    # Nombre de la experiencia
    titulo = models.CharField(max_length=150)

    # Descripción de la actividad
    descripcion = models.TextField()

    # Precio de la experiencia
    precio = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(0)]
    )

    # Número máximo de participantes
    cupo_maximo = models.PositiveIntegerField(
        validators=[MinValueValidator(1)]
    )

    # Fecha y hora de la actividad
    fecha_hora = models.DateTimeField()

    # Categoría a la que pertenece la experiencia
    categoria = models.ForeignKey(
        Categoria,
        on_delete=models.PROTECT,
        related_name='experiencias'
    )

    # Usuario que creó la experiencia
    creador = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='experiencias_creadas'
    )

    # Indica si la experiencia está disponible
    activo = models.BooleanField(default=True)

    # Ordena las experiencias por fecha
    class Meta:
        ordering = ['fecha_hora']

    # Muestra el título de la experiencia
    def __str__(self):
        return self.titulo


# MODELO DE RESERVAS

# Permite registrar las reservas de los turistas
class Reserva(models.Model):

    # Estados disponibles para el pago
    ESTADO_PENDIENTE = 'Pendiente'
    ESTADO_CONFIRMADO = 'Confirmado'

    # Opciones del estado de pago
    OPCIONES_ESTADO = [
        (ESTADO_PENDIENTE, 'Pendiente'),
        (ESTADO_CONFIRMADO, 'Confirmado'),
    ]

    # Usuario que realiza la reserva
    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='reservas'
    )

    # Experiencia que está reservando
    experiencia = models.ForeignKey(
        Experiencia,
        on_delete=models.CASCADE,
        related_name='reservas'
    )

    # Fecha en la que se realiza la inscripción
    fecha_inscripcion = models.DateTimeField(
        auto_now_add=True
    )

    # Estado de pago de la reserva
    estado_pago = models.CharField(
        max_length=10,
        choices=OPCIONES_ESTADO,
        default=ESTADO_PENDIENTE
    )

    # Ordena las reservas desde la más reciente
    class Meta:
        ordering = ['-fecha_inscripcion']

    # Muestra el usuario y la experiencia reservada
    def __str__(self):
        return f"{self.usuario.username} - {self.experiencia.titulo}"
