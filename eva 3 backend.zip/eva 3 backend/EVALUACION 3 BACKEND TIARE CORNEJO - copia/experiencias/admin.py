
# IMPORTACIONES

# Se importa el administrador de Django
from django.contrib import admin

# Se importan los modelos de experiencias
from experiencias import models as ModelsExperiencias


# ADMINISTRACIÓN DE CATEGORÍAS

# Se configura el listado de categorías
class CategoriaAdmin(admin.ModelAdmin):

    # Campos que se mostrarán
    list_display = ['id', 'nombre', 'descripcion', 'estado']

    # Permite buscar categorías
    search_fields = ['nombre']

    # Permite filtrar por estado
    list_filter = ['estado']


# ADMINISTRACIÓN DE EXPERIENCIAS

# Se adapta la administración de cursos del compañero
class ExperienciaAdmin(admin.ModelAdmin):

    # Campos que aparecerán en el listado
    list_display = [
        'id',
        'titulo',
        'precio',
        'cupo_maximo',
        'fecha_hora',
        'categoria',
        'creador',
        'activo'
    ]

    # Permite buscar experiencias
    search_fields = ['titulo']

    # Permite filtrar por categoría y estado
    list_filter = ['categoria', 'activo']


# ADMINISTRACIÓN DE RESERVAS

# Se configura la administración de las reservas
class ReservaAdmin(admin.ModelAdmin):

    # Campos que aparecerán en el listado
    list_display = [
        'id',
        'usuario',
        'experiencia',
        'fecha_inscripcion',
        'estado_pago'
    ]

    # Permite buscar reservas
    search_fields = [
        'usuario__username',
        'experiencia__titulo'
    ]

    # Permite filtrar por estado de pago
    list_filter = ['estado_pago']


# REGISTRO DE MODELOS

# Se registran los modelos para mostrarlos en Django Admin
admin.site.register(ModelsExperiencias.Categoria, CategoriaAdmin)
admin.site.register(ModelsExperiencias.Experiencia, ExperienciaAdmin)
admin.site.register(ModelsExperiencias.Reserva, ReservaAdmin)
