
# IMPORTACIONES

# Se importan los formularios de Django
from django import forms

# Se importan los modelos de la aplicación experiencias
from experiencias import models as ModelsExperiencias

# Se importan los validadores de Django
from django.core import validators

# Se importa timezone para trabajar con las fechas
from django.utils import timezone

# FORMULARIO DE CATEGORÍAS

# Permite crear y modificar las categorías del ecoparque
class CategoriaForm(forms.ModelForm):

    class Meta:
        model = ModelsExperiencias.Categoria
        fields = ['nombre', 'descripcion', 'estado']

    # Nombre de la categoría
    nombre = forms.CharField(
        validators=[
            validators.MinLengthValidator(3),
            validators.MaxLengthValidator(100)
        ],
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Ej. Trekking'
        }),
        label='Nombre de la categoría'
    )

    # Descripción de la categoría
    descripcion = forms.CharField(
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 3,
            'placeholder': 'Descripción de la categoría'
        }),
        label='Descripción'
    )

    # Estado de la categoría
    estado = forms.BooleanField(
        required=False,
        initial=True,
        widget=forms.CheckboxInput(attrs={
            'class': 'form-check-input'
        }),
        label='Categoría activa'
    )

# FORMULARIO DE EXPERIENCIAS

# Adaptación de RegisterCursoForm del compañero
class ExperienciaForm(forms.ModelForm):

    class Meta:
        model = ModelsExperiencias.Experiencia
        fields = [
            'titulo',
            'descripcion',
            'precio',
            'cupo_maximo',
            'fecha_hora',
            'categoria',
            'activo'
        ]

    # Título de la experiencia
    titulo = forms.CharField(
        validators=[
            validators.MinLengthValidator(3),
            validators.MaxLengthValidator(150)
        ],
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Ej. Trekking por la montaña'
        }),
        label='Título de la experiencia'
    )

    # Descripción de la actividad
    descripcion = forms.CharField(
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 3,
            'placeholder': 'Descripción de la actividad'
        }),
        label='Descripción'
    )

    # Precio de la experiencia
    precio = forms.DecimalField(
        min_value=0,
        max_digits=10,
        decimal_places=2,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'min': '0',
            'step': '0.01'
        }),
        label='Precio de la experiencia'
    )

    # Cantidad máxima de participantes
    cupo_maximo = forms.IntegerField(
        min_value=1,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'min': '1'
        }),
        label='Cupo máximo'
    )

    # Fecha y hora de la actividad
    fecha_hora = forms.DateTimeField(
        input_formats=['%Y-%m-%dT%H:%M'],
        widget=forms.DateTimeInput(
            format='%Y-%m-%dT%H:%M',
            attrs={
                'class': 'form-control',
                'type': 'datetime-local'
            }
        ),
        label='Fecha y hora de realización'
    )

    # Se muestran las categorías activas
    categoria = forms.ModelChoiceField(
        queryset=ModelsExperiencias.Categoria.objects.filter(
            estado=True
        ),
        widget=forms.Select(attrs={
            'class': 'form-control'
        }),
        label='Categoría'
    )

    # Indica si la actividad está disponible
    activo = forms.BooleanField(
        required=False,
        initial=True,
        widget=forms.CheckboxInput(attrs={
            'class': 'form-check-input'
        }),
        label='Experiencia activa'
    )

    # VALIDACIÓN DE FECHA

    # Se comprueba que la actividad no tenga una fecha pasada
    def clean_fecha_hora(self):

        # Se obtiene la fecha ingresada
        fecha = self.cleaned_data['fecha_hora']

        # Se valida una fecha nueva o modificada
        if not self.instance.pk or 'fecha_hora' in self.changed_data:
            if fecha <= timezone.now():
                raise forms.ValidationError(
                    'La fecha debe ser posterior a la actual.'
                )

        # Se devuelve la fecha cuando es válida
        return fecha

# FORMULARIO DE RESERVAS

# Adaptación de la inscripción a cursos del compañero
class ReservaForm(forms.ModelForm):

    class Meta:
        model = ModelsExperiencias.Reserva
        fields = ['experiencia']

    # Campo para seleccionar la experiencia
    experiencia = forms.ModelChoiceField(
        queryset=ModelsExperiencias.Experiencia.objects.none(),
        widget=forms.Select(attrs={
            'class': 'form-control'
        }),
        label='Seleccionar experiencia'
    )

    # Se cargan las experiencias disponibles
    def __init__(self, *args, **kwargs):

        # Se inicializa el formulario
        super().__init__(*args, **kwargs)

        # Solo aparecen experiencias activas y futuras
        self.fields['experiencia'].queryset = (
            ModelsExperiencias.Experiencia.objects.filter(
                activo=True,
                categoria__estado=True,
                fecha_hora__gt=timezone.now()
            )
        )

# FORMULARIO DE ESTADO DE PAGO

# Permite actualizar el estado de pago de una reserva
class ReservaEstadoForm(forms.ModelForm):

    class Meta:
        model = ModelsExperiencias.Reserva
        fields = ['estado_pago']

    # Permite seleccionar el estado del pago
    estado_pago = forms.ChoiceField(
        choices=ModelsExperiencias.Reserva.OPCIONES_ESTADO,
        widget=forms.Select(attrs={
            'class': 'form-control'
        }),
        label='Estado del pago'
    )
