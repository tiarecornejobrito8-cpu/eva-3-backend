# IMPORTACIONES

# Mostrar páginas y redireccionar
from django.shortcuts import (render,redirect,get_object_or_404)

# Rutas del proyecto 
from django.urls import reverse_lazy

# Vistas de registro e inicio de sesión
from django.views.generic import CreateView
from django.contrib.auth.views import LoginView

# Control de sesiones y permisos
from django.contrib.auth.mixins import (
    LoginRequiredMixin,
    UserPassesTestMixin
)

from django.contrib.auth.decorators import login_required

# Acceso denegado
from django.core.exceptions import PermissionDenied

# Permitir eliminación solo por POST
from django.views.decorators.http import require_POST

# Mensajes del sistema
from django.contrib import messages

# Formularios y modelos
from cuentas import forms as UsuariosForms
from cuentas import models as ModelsUser

# FUNCIÓN PARA VALIDAR ADMINISTRADORES

def es_administrador(usuario):

    return (
        usuario.is_authenticated
        and usuario.is_active
        and (
            usuario.is_superuser
            or (
                usuario.is_custom_admin
                and usuario.is_staff
            )
        )
    )

# PROTEGER CUENTAS ADMINISTRATIVAS

def cuenta_protegida(usuario):

    return (
        usuario.is_superuser
        or usuario.is_staff
        or usuario.is_custom_admin
    )

# REGISTRO PÚBLICO DE TURISTAS

class CrearCuentaViewTurista(CreateView):

    # Formulario de registro público
    form_class = UsuariosForms.TuristaSignUpForm

    # Plantilla del formulario
    template_name = 'cuentas/registro_turista.html'

    # Volver al inicio de sesión
    success_url = reverse_lazy('iniciar_sesion')

# REGISTRO DE GUÍAS

class CrearCuentaViewGuia(
    LoginRequiredMixin,
    UserPassesTestMixin,
    CreateView
):

    # Formulario exclusivo de guías
    form_class = UsuariosForms.GuiaSignUpForm

    # REGISTRO DE GUÍAS / OPERADORES
    template_name = 'cuentas/registro_guia.html'

    # Volver al listado de SB Admin 2
    success_url = reverse_lazy('listar_usuarios')

    login_url = reverse_lazy('iniciar_sesion')

    raise_exception = True

    def test_func(self):

        return es_administrador(
            self.request.user
        )

# INICIO DE SESIÓN

class IniciarSesionView(LoginView):

    # Formulario existente
    template_name = 'cuentas/iniciar_sesion.html'

    redirect_authenticated_user = False

    # Elegir destino según el rol
    def get_success_url(self):

        # Respetar una redirección válida
        destino = self.get_redirect_url()

        if destino:
            return destino

        usuario = self.request.user

        # Administrador
        if es_administrador(usuario):

            return reverse_lazy(
                'listar_categorias'
            )

        # Guía
        elif usuario.is_guia:

            return reverse_lazy(
                'listar_experiencias'
            )

        # Turista
        elif usuario.is_turista:

            return reverse_lazy(
                'catalogo_experiencias'
            )

        return reverse_lazy('landingPage')

# CRUD DE USUARIOS - SB ADMIN 2

# LISTAR USUARIOS

@login_required(login_url='iniciar_sesion')
def listarUsuarios(request):

    # Solo administradores
    if not es_administrador(request.user):
        raise PermissionDenied

    # Consultar usuarios en MySQL
    usuarios = (
        ModelsUser.User.objects
        .all()
        .order_by('username')
    )

    data = {
        'usuarios': usuarios
    }

    return render(
        request,
        'cuentas/lista_usuarios.html',
        data
    )

# REGISTRAR USUARIO

@login_required(login_url='iniciar_sesion')
def registrarUsuario(request):

    if not es_administrador(request.user):
        raise PermissionDenied

    # Formulario vacío
    formUsuario = UsuariosForms.UsuarioPanelCrearForm()

    if request.method == 'POST':

        formUsuario = UsuariosForms.UsuarioPanelCrearForm(
            request.POST
        )

        if formUsuario.is_valid():

            # Guardar en la misma base MySQL
            formUsuario.save()

            messages.success(
                request,
                'Usuario registrado correctamente.'
            )

            return redirect('listar_usuarios')

    data = {
        'formKey': formUsuario,
        'titulo_pagina': 'Registrar usuario'
    }

    return render(
        request,
        'cuentas/formulario_usuario.html',
        data
    )

# EDITAR USUARIO

@login_required(login_url='iniciar_sesion')
def editarUsuario(request, id_usuario):

    if not es_administrador(request.user):
        raise PermissionDenied

    # Buscar usuario existente
    usuario = get_object_or_404(
        ModelsUser.User,
        pk=id_usuario
    )

    # Proteger administradores y cuentas staff
    if cuenta_protegida(usuario):
        raise PermissionDenied

    # Mostrar información actual
    formUsuario = UsuariosForms.UsuarioPanelEditarForm(
        instance=usuario
    )

    if request.method == 'POST':

        formUsuario = UsuariosForms.UsuarioPanelEditarForm(
            request.POST,
            instance=usuario
        )

        if formUsuario.is_valid():

            formUsuario.save()

            messages.success(
                request,
                'Usuario actualizado correctamente.'
            )

            return redirect('listar_usuarios')

    data = {
        'formKey': formUsuario,
        'titulo_pagina': 'Editar usuario'
    }

    return render(
        request,
        'cuentas/formulario_usuario.html',
        data
    )

# ELIMINAR USUARIO

@login_required(login_url='iniciar_sesion')
@require_POST
def eliminarUsuario(request, id_usuario):

    if not es_administrador(request.user):
        raise PermissionDenied

    usuario = get_object_or_404(
        ModelsUser.User,
        pk=id_usuario
    )

    # No permitir eliminar al administrador
    # ni a otros usuarios administrativos.
    if (
        usuario.pk == request.user.pk
        or cuenta_protegida(usuario)
    ):

        messages.error(
            request,
            'No se puede eliminar una cuenta administrativa.'
        )

        return redirect('listar_usuarios')

    # Verificar si tiene experiencias relacionadas
    tiene_experiencias = (
        usuario.experiencias_creadas.exists()
    )

    # Verificar si tiene reservas relacionadas
    tiene_reservas = (
        usuario.reservas.exists()
    )

    # Proteger los datos asociados
    if tiene_experiencias or tiene_reservas:

        messages.error(
            request,
            'No se puede eliminar el usuario porque '
            'tiene experiencias o reservas registradas. '
            'Puedes desactivar su cuenta.'
        )

        return redirect('listar_usuarios')

    # Eliminar usuario sin datos relacionados
    usuario.delete()

    messages.success(
        request,
        'Usuario eliminado correctamente.'
    )

    return redirect('listar_usuarios')
