
# IMPORTACIONES 

# inportacion del administrador  Django
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

# inportacion de los modelos de usuarios
from cuentas import models as ModelsUser


# ADMINISTRACIÓN DE USUARIOS

# configuración del administrador de usuarios
class UsuarioAdmin(UserAdmin):

    # Se agrega el rol al formulario de edición
    fieldsets = UserAdmin.fieldsets + (
        ('Datos del ecoparque', {
            'fields': ('rol',)
        }),
    )

    # Se agrega el rol al formulario de creación
    add_fieldsets = UserAdmin.add_fieldsets + (
        ('Datos del ecoparque', {
            'fields': ('rol',)
        }),
    )

    # Campos que aparecerán en el listado
    list_display = [
        'username',
        'first_name',
        'last_name',
        'email',
        'rol',
        'is_staff'
    ]

    # Permite buscar usuarios
    search_fields = [
        'username',
        'first_name',
        'last_name',
        'email'
    ]

    # Permite filtrar los usuarios por rol
    list_filter = UserAdmin.list_filter + ('rol',)


# Se registra el modelo User en Django Admin
admin.site.register(ModelsUser.User, UsuarioAdmin)
