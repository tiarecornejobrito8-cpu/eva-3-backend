# IMPORTACIONES

# Formularios de Django
from django import forms

# Formulario para crear usuarios
from django.contrib.auth.forms import UserCreationForm

# Modelo de usuarios
from cuentas import models as ModelsUser

# FORMULARIO BASE PARA REGISTRAR CUENTAS


class RegistroUsuarioBaseForm(UserCreationForm):

    # El correo es obligatorio
    email = forms.EmailField(
        label='Dirección de correo electrónico',
        required=True
    )

    class Meta:

        model = ModelsUser.User

        fields = [
            'username',
            'first_name',
            'last_name',
            'email',
            'password1',
            'password2'
        ]

    def __init__(self, *args, **kwargs):

        super().__init__(*args, **kwargs)

        # Agregar estilos Bootstrap
        for campo in self.fields.values():

            campo.widget.attrs.update({
                'class': 'form-control'
            })

        # Datos obligatorios
        self.fields['first_name'].required = True
        self.fields['last_name'].required = True

    #  sirve para Verificar que el correo no esté registrado
    def clean_email(self):

        email = self.cleaned_data['email'].strip()

        existe = (
            ModelsUser.User.objects
            .filter(email__iexact=email)
            .exclude(pk=self.instance.pk)
            .exists()
        )

        if existe:

            raise forms.ValidationError(
                'Este correo electrónico ya está registrado.'
            )

        return email

# REGISTRO PÚBLICO DE TURISTAS

class TuristaSignUpForm(RegistroUsuarioBaseForm):

    def save(self, commit=True):

        usuario = super().save(commit=False)

        # Asignar rol Turista
        usuario.rol = ModelsUser.User.ROL_TURISTA

        # No permite acceso a Django Admin
        usuario.is_staff = False
        usuario.is_superuser = False
        usuario.is_active = True

        if commit:
            usuario.save()

        return usuario

# REGISTRO DE GUÍAS / OPERADORES

class GuiaSignUpForm(RegistroUsuarioBaseForm):

    def save(self, commit=True):

        usuario = super().save(commit=False)

        # Asignar rol Guía
        usuario.rol = ModelsUser.User.ROL_GUIA

        # Los guías no tienen acceso a Django Admin
        usuario.is_staff = False
        usuario.is_superuser = False
        usuario.is_active = True

        if commit:
            usuario.save()

        return usuario

# ROLES PERMITIDOS EN EL PANEL SB ADMIN 2

ROLES_PANEL = [
    (
        ModelsUser.User.ROL_GUIA,
        'Guía / Operador'
    ),
    (
        ModelsUser.User.ROL_TURISTA,
        'Turista / Cliente'
    ),
]

# CREACION DE USUARIOS DESDE SB ADMIN 2

class UsuarioPanelCrearForm(RegistroUsuarioBaseForm):

    # El administrador selecciona el rol
    rol = forms.ChoiceField(
        label='Rol del usuario',
        choices=ROLES_PANEL
    )

    class Meta:

        model = ModelsUser.User

        fields = [
            'username',
            'first_name',
            'last_name',
            'email',
            'rol',
            'password1',
            'password2'
        ]

    def save(self, commit=True):

        usuario = super().save(commit=False)

        # Solo se admiten guías o turistas
        usuario.rol = self.cleaned_data['rol']

        # Sin acceso administrativo
        usuario.is_staff = False
        usuario.is_superuser = False
        usuario.is_active = True

        if commit:
            usuario.save()

        return usuario

# EDITAR USUARIOS DESDE SB ADMIN 2

class UsuarioPanelEditarForm(forms.ModelForm):

    email = forms.EmailField(
        label='Dirección de correo electrónico',
        required=True
    )

    rol = forms.ChoiceField(
        label='Rol del usuario',
        choices=ROLES_PANEL
    )

    class Meta:

        model = ModelsUser.User

        fields = [
            'username',
            'first_name',
            'last_name',
            'email',
            'rol',
            'is_active'
        ]

        labels = {
            'username': 'Nombre de usuario',
            'first_name': 'Nombre',
            'last_name': 'Apellidos',
            'is_active': 'Cuenta activa'
        }

    def __init__(self, *args, **kwargs):

        super().__init__(*args, **kwargs)

        for campo in self.fields.values():

            # Estilo especial para checkbox
            if isinstance(
                campo.widget,
                forms.CheckboxInput
            ):

                campo.widget.attrs.update({
                    'class': 'form-check-input'
                })

            else:

                campo.widget.attrs.update({
                    'class': 'form-control'
                })

        self.fields['first_name'].required = True
        self.fields['last_name'].required = True

    # Evita duplicar el correo electrónico
    def clean_email(self):

        email = self.cleaned_data['email'].strip()

        existe = (
            ModelsUser.User.objects
            .filter(email__iexact=email)
            .exclude(pk=self.instance.pk)
            .exists()
        )

        if existe:

            raise forms.ValidationError(
                'Este correo electrónico ya está registrado.'
            )

        return email
