
# IMPORTACIONES

from django.db import models
from django.contrib.auth.models import AbstractUser


# MODELO DE USUARIOS

# Se crea el usuario personalizado utilizando AbstractUser
class User(AbstractUser):

    # Definición de roles para los usuarios
    ROL_ADMIN = "Administrador"
    ROL_GUIA = "Guia"
    ROL_TURISTA = "Turista"

    # Lista de roles disponibles para los usuarios
    OPCIONES_ROL = [
        (ROL_ADMIN, "Administrador"),
        (ROL_GUIA, "Guía / Operador"),
        (ROL_TURISTA, "Turista / Cliente"),
    ]

    # Este campo permite asignar un rol a cada usuario
    # Por defecto los usuarios nuevos serán turistas
    rol = models.CharField(
        max_length=15,
        choices=OPCIONES_ROL,
        default=ROL_TURISTA
    )

    # VALIDACIÓN DE ROLES

    # Se verifica si el usuario es administrador
    @property
    def is_custom_admin(self):
        return self.rol == self.ROL_ADMIN or self.is_superuser

    # Se verifica si el usuario es guía u operador
    @property
    def is_guia(self):
        return self.rol == self.ROL_GUIA

    # Se verifica si el usuario es turista
    @property
    def is_turista(self):
        return self.rol == self.ROL_TURISTA and not self.is_superuser

    # REPRESENTACIÓN DEL USUARIO

    # Se muestra el nombre del usuario y su rol
    # cuando se consultan los registros
    def __str__(self):
        return f"{self.username} - {self.rol}"
