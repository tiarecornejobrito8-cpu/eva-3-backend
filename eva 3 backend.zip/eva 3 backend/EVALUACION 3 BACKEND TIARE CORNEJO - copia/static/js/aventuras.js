// JAVASCRIPT DE LA PÁGINA PRINCIPAL

// Esperar a que se cargue la página
document.addEventListener(
    'DOMContentLoaded',
    function () {

        // Obtener el menú de navegación
        const menu = document.getElementById(
            'menuPrincipal'
        );

        // Comprobar que existe el menú
        // y que Bootstrap está disponible
        if (!menu || typeof bootstrap === 'undefined') {
            return;
        }

        // Obtener los enlaces internos del menú
        const enlaces = menu.querySelectorAll(
            'a[href^="#"]'
        );

        // Recorrer cada enlace
        enlaces.forEach(function (enlace) {

            // Cuando el usuario selecciona una sección
            enlace.addEventListener('click', function () {

                // Comprobar si el menú está abierto
                if (menu.classList.contains('show')) {

                    // Cerrar el menú de Bootstrap
                    bootstrap.Collapse
                        .getOrCreateInstance(menu)
                        .hide();

                }

            });

        });

    }
);
