// JAVASCRIPT PARA FORMULARIOS DE CUENTAS

// Espera a que la página termine de cargar
document.addEventListener(
    'DOMContentLoaded',
    function () {

        // Busca los botones para mostrar contraseña
        const botones = document.querySelectorAll(
            '[data-mostrar-clave]'
        );

        // Recorre cada botón
        botones.forEach(function (boton) {

            boton.addEventListener('click', function () {

                // Obtiene el campo de contraseña
                const campo = document.getElementById(
                    boton.dataset.mostrarClave
                );

                if (!campo) {
                    return;
                }

                // Comprueba si la contraseña está oculta
                const estaOculta = campo.type === 'password';

                // Cambia el tipo de campo
                campo.type = estaOculta ? 'text' : 'password';

                // Cambia el texto del botón
                boton.textContent = estaOculta
                    ? 'Ocultar'
                    : 'Mostrar';

                // Actualiza su estado accesible
                boton.setAttribute(
                    'aria-pressed',
                    String(estaOculta)
                );

            });

        });

    }
);
