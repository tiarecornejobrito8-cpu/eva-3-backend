
# IMPORTACIONES
from django.shortcuts import render


# PÁGINA PRINCIPAL DEL ECOPARQUE
def landingPage(request):

    # Se muestra la pagina principal
    return render(request, 'landingPage.html')
